// Edge function: generate website analysis, 5 emails, and 10 subject lines
// Uses Lovable AI Gateway (no key needed beyond LOVABLE_API_KEY).

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface Body {
  business: {
    name: string;
    website?: string;
    industry?: string;
    contact_name?: string;
    location?: string;
    tone?: string;
  };
  agency: {
    agency_name?: string;
    agency_website?: string;
    agency_contact?: string;
    services?: string;
    portfolio?: string;
    usp?: string;
    target_industry?: string;
    email_length?: string;
    personalization_level?: string;
    cta_style?: string;
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { business, agency } = (await req.json()) as Body;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are an elite cold-outreach copywriter who works with web design agencies.
You analyze prospect websites and produce specific, honest, persuasive outreach emails.
Rules:
- Never invent fake stats, fake clients, or exaggerated claims.
- Reference concrete things you can reasonably infer from the prospect's industry, location, and stated website.
- Avoid spam triggers, all-caps, excessive emojis, and pushy language.
- Each email mentions the business by name and references specific observations.
- Build trust through specificity, not hype.
- Output ONLY valid JSON matching the requested tool schema. No prose outside the tool call.`;

    const userPrompt = `Generate a website audit and outreach package.

PROSPECT:
- Business: ${business.name}
- Website: ${business.website || "(not provided — infer reasonable assumptions for the industry)"}
- Industry: ${business.industry || "(unknown)"}
- Contact name: ${business.contact_name || "(unknown — use a generic respectful opener)"}
- Location: ${business.location || "(unknown)"}
- Desired tone: ${business.tone || "Professional"}

AGENCY:
- Name: ${agency.agency_name || "(unspecified agency)"}
- Website: ${agency.agency_website || ""}
- Contact: ${agency.agency_contact || ""}
- Services: ${agency.services || "web design, redesigns, conversion optimization"}
- Portfolio: ${agency.portfolio || ""}
- USP: ${agency.usp || ""}
- Target industry focus: ${agency.target_industry || ""}
- Preferred email length: ${agency.email_length || "Standard"}
- Personalization level: ${agency.personalization_level || "High"}
- CTA style: ${agency.cta_style || "Soft"}

TASK:
1) Audit the prospect's likely website covering: design quality, mobile responsiveness, loading speed,
   outdated elements, missing CTAs, SEO weaknesses, UX issues, branding inconsistencies, and conversion opportunities.
   Be specific to ${business.industry || "their industry"} and ${business.location || "their market"} where relevant.
2) Generate 5 outreach emails: short (~80 words), standard (~150 words), premium (~220 words),
   followup_1 (sent 3 days later), followup_2 (sent 7 days later, last touch).
   Each must mention "${business.name}", reference specific audit findings, demonstrate expertise, and end with a clear CTA.
   Include a signature line using the agency name and contact.
3) Generate 10 subject lines total: 2 each in curiosity, professional, direct, benefit, personalized categories.
   Keep them under 60 characters. Personalized ones should reference the business or location.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "deliver_outreach_package",
              description: "Return the website audit, 5 emails, and 10 subject lines.",
              parameters: {
                type: "object",
                properties: {
                  analysis: {
                    type: "object",
                    properties: {
                      summary: { type: "string" },
                      design_quality: { type: "string" },
                      mobile_responsiveness: { type: "string" },
                      loading_speed: { type: "string" },
                      outdated_elements: { type: "string" },
                      missing_ctas: { type: "string" },
                      seo: { type: "string" },
                      ux: { type: "string" },
                      branding: { type: "string" },
                      conversion_opportunities: {
                        type: "array",
                        items: { type: "string" },
                      },
                    },
                    required: [
                      "summary",
                      "design_quality",
                      "mobile_responsiveness",
                      "loading_speed",
                      "outdated_elements",
                      "missing_ctas",
                      "seo",
                      "ux",
                      "branding",
                      "conversion_opportunities",
                    ],
                    additionalProperties: false,
                  },
                  emails: {
                    type: "object",
                    properties: {
                      short: { type: "string" },
                      standard: { type: "string" },
                      premium: { type: "string" },
                      followup_1: { type: "string" },
                      followup_2: { type: "string" },
                    },
                    required: ["short", "standard", "premium", "followup_1", "followup_2"],
                    additionalProperties: false,
                  },
                  subject_lines: {
                    type: "object",
                    properties: {
                      curiosity: { type: "array", items: { type: "string" } },
                      professional: { type: "array", items: { type: "string" } },
                      direct: { type: "array", items: { type: "string" } },
                      benefit: { type: "array", items: { type: "string" } },
                      personalized: { type: "array", items: { type: "string" } },
                    },
                    required: [
                      "curiosity",
                      "professional",
                      "direct",
                      "benefit",
                      "personalized",
                    ],
                    additionalProperties: false,
                  },
                },
                required: ["analysis", "emails", "subject_lines"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: {
          type: "function",
          function: { name: "deliver_outreach_package" },
        },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit reached. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({
            error: "AI credits exhausted. Add credits in your workspace settings.",
          }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      throw new Error("AI gateway error");
    }

    const json = await response.json();
    const toolCall = json.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("AI did not return a tool call");
    const args = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(args), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-email error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
