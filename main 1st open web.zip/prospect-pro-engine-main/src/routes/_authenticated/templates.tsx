import { createFileRoute, Link } from "@tanstack/react-router";
import {
  UtensilsCrossed,
  Stethoscope,
  Scale,
  Home,
  Store,
  ShoppingBag,
  HardHat,
  HeartPulse,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/templates")({
  component: TemplatesPage,
});

const templates = [
  {
    icon: UtensilsCrossed,
    title: "Restaurants",
    body: "Boost reservations, menu visibility, and mobile ordering UX.",
    industry: "Restaurant",
  },
  {
    icon: Stethoscope,
    title: "Dentists",
    body: "Modern booking flows and trust-building for dental practices.",
    industry: "Dental Practice",
  },
  {
    icon: Scale,
    title: "Law Firms",
    body: "Authoritative redesigns that capture qualified inbound leads.",
    industry: "Law Firm",
  },
  {
    icon: Home,
    title: "Real Estate Agencies",
    body: "Listings, IDX integration, and lead-magnet landing pages.",
    industry: "Real Estate",
  },
  {
    icon: Store,
    title: "Local Businesses",
    body: "Local SEO + mobile-first redesigns that win the neighborhood.",
    industry: "Local Business",
  },
  {
    icon: ShoppingBag,
    title: "E-commerce Stores",
    body: "Conversion-focused PDPs, checkout polish, and retention.",
    industry: "E-commerce",
  },
  {
    icon: HardHat,
    title: "Contractors",
    body: "Trust signals, gallery showcases, and quote-request flows.",
    industry: "Contractor",
  },
  {
    icon: HeartPulse,
    title: "Healthcare Clinics",
    body: "HIPAA-aware patient portals and modern booking flows.",
    industry: "Healthcare",
  },
];

function TemplatesPage() {
  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6 md:p-8">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Templates</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Niche presets that bias the AI toward what matters in that industry.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {templates.map((t) => (
          <Card
            key={t.title}
            className="group border-border bg-gradient-surface shadow-elegant transition hover:border-primary/40"
          >
            <CardContent className="space-y-3 p-5">
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20">
                <t.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg font-semibold">{t.title}</h3>
              <p className="text-sm text-muted-foreground">{t.body}</p>
              <Link to="/generate">
                <Button size="sm" variant="outline" className="mt-1">
                  Use template
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
