import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { Loader2, Sparkles, Globe, AlertTriangle, CheckCircle2, Copy } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/generate")({
  component: GeneratePage,
});

function getStoredAgency() {
  try {
    return JSON.parse(localStorage.getItem("leadforge-agency") || "{}");
  } catch {
    return {};
  }
}

function addStoredLead(lead: Record<string, unknown>) {
  const leads = JSON.parse(localStorage.getItem("leadforge-leads") || "[]");
  leads.unshift({
    ...lead,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString(),
  });
  localStorage.setItem("leadforge-leads", JSON.stringify(leads));
}

type GenerateResponse = {
  analysis: {
    summary: string;
    design_quality: string;
    mobile_responsiveness: string;
    loading_speed: string;
    outdated_elements: string;
    missing_ctas: string;
    seo: string;
    ux: string;
    branding: string;
    conversion_opportunities: string[];
  };
  emails: {
    short: string;
    standard: string;
    premium: string;
    followup_1: string;
    followup_2: string;
  };
  subject_lines: {
    curiosity: string[];
    professional: string[];
    direct: string[];
    benefit: string[];
    personalized: string[];
  };
};

function GeneratePage() {
  const navigate = useNavigate();
  const [businessName, setBusinessName] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [industry, setIndustry] = useState("");
  const [contactName, setContactName] = useState("");
  const [location, setLocation] = useState("");
  const [websiteType, setWebsiteType] = useState("");
  const [companySize, setCompanySize] = useState("");
  const [servicesNeeded, setServicesNeeded] = useState("");
  const [budgetRange, setBudgetRange] = useState("");
  const [tone, setTone] = useState("Professional");
  const [result, setResult] = useState<GenerateResponse | null>(null);
  const [leadId, setLeadId] = useState<string | null>(null);

  const agency = getStoredAgency();

  const mutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("generate-email", {
        body: {
          business: {
            name: businessName,
            website: websiteUrl,
            industry,
            contact_name: contactName,
            location,
            website_type: websiteType,
            company_size: companySize,
            services_needed: servicesNeeded,
            budget_range: budgetRange,
            tone,
          },
          agency: agency ?? {},
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data as GenerateResponse;
    },
    onSuccess: async (data) => {
      setResult(data);
      const id = crypto.randomUUID();
      addStoredLead({
        id,
        business_name: businessName,
        website_url: websiteUrl,
        industry,
        contact_name: contactName,
        location,
        website_type: websiteType,
        company_size: companySize,
        services_needed: servicesNeeded,
        budget_range: budgetRange,
        tone,
        analysis: data.analysis,
        emails: data.emails,
        subject_lines: data.subject_lines,
      });
      setLeadId(id);
      toast.success("Lead generated and saved");
    },
    onError: (err: Error) => {
      toast.error(err.message || "Generation failed");
    },
  });

  const copy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6 md:p-8">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Generate Email</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Drop in a prospect — get a website audit, 5 emails, and 10 subject lines.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[400px_1fr]">
        <Card className="border-border bg-gradient-surface shadow-elegant">
          <CardHeader>
            <CardTitle className="font-display text-lg">Prospect details</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                if (!businessName.trim()) return toast.error("Business name required");
                setResult(null);
                setLeadId(null);
                mutation.mutate();
              }}
            >
              <div className="space-y-2">
                <Label htmlFor="bn">Business name *</Label>
                <Input
                  id="bn"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  placeholder="Joe's Pizzeria"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="url">Website URL</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="url"
                    className="pl-9"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                    placeholder="joespizza.com"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ind">Industry / niche</Label>
                <Input
                  id="ind"
                  value={industry}
                  onChange={(e) => setIndustry(e.target.value)}
                  placeholder="Restaurant"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="cn">Contact</Label>
                  <Input
                    id="cn"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    placeholder="Joe"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="loc">Location</Label>
                  <Input
                    id="loc"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Brooklyn"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Website type</Label>
                  <Select value={websiteType} onValueChange={setWebsiteType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="E-commerce">E-commerce</SelectItem>
                      <SelectItem value="Service">Service</SelectItem>
                      <SelectItem value="Portfolio">Portfolio</SelectItem>
                      <SelectItem value="Blog">Blog</SelectItem>
                      <SelectItem value="SaaS">SaaS</SelectItem>
                      <SelectItem value="Landing page">Landing page</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Company size</Label>
                  <Select value={companySize} onValueChange={setCompanySize}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 employees</SelectItem>
                      <SelectItem value="11-50">11-50 employees</SelectItem>
                      <SelectItem value="51-200">51-200 employees</SelectItem>
                      <SelectItem value="200+">200+ employees</SelectItem>
                      <SelectItem value="Solo founder">Solo founder</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Services needed</Label>
                  <Select value={servicesNeeded} onValueChange={setServicesNeeded}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Full redesign">Full redesign</SelectItem>
                      <SelectItem value="New website">New website</SelectItem>
                      <SelectItem value="SEO optimization">SEO optimization</SelectItem>
                      <SelectItem value="Branding">Branding</SelectItem>
                      <SelectItem value="E-commerce setup">E-commerce setup</SelectItem>
                      <SelectItem value="Maintenance">Maintenance</SelectItem>
                      <SelectItem value="Not sure">Not sure</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Budget range</Label>
                  <Select value={budgetRange} onValueChange={setBudgetRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select budget" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="$1k-$5k">$1k - $5k</SelectItem>
                      <SelectItem value="$5k-$15k">$5k - $15k</SelectItem>
                      <SelectItem value="$15k-$50k">$15k - $50k</SelectItem>
                      <SelectItem value="$50k+">$50k+</SelectItem>
                      <SelectItem value="Not disclosed">Not disclosed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Email tone</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Professional">Professional</SelectItem>
                    <SelectItem value="Friendly">Friendly</SelectItem>
                    <SelectItem value="Premium">Premium</SelectItem>
                    <SelectItem value="Direct">Direct</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {!agency?.agency_name && (
                <div className="rounded-md border border-warning/30 bg-warning/5 p-3 text-xs text-muted-foreground">
                  <AlertTriangle className="mr-1 inline h-3 w-3 text-warning" />
                  Add your agency info in{" "}
                  <button
                    type="button"
                    className="underline"
                    onClick={() => navigate({ to: "/settings" })}
                  >
                    Settings
                  </button>{" "}
                  for sharper personalization.
                </div>
              )}
              <Button
                type="submit"
                disabled={mutation.isPending}
                className="w-full bg-gradient-primary shadow-glow"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" /> Generate
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {!result && !mutation.isPending && (
            <Card className="border-dashed border-border bg-card/30 shadow-elegant">
              <CardContent className="flex flex-col items-center justify-center py-20 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-primary shadow-glow">
                  <Sparkles className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="mt-4 font-display text-xl font-semibold">
                  Ready when you are
                </h3>
                <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                  Fill in the prospect details and we'll audit their site and craft your
                  outreach in seconds.
                </p>
              </CardContent>
            </Card>
          )}

          {mutation.isPending && (
            <Card className="border-border bg-gradient-surface shadow-elegant">
              <CardContent className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <p className="mt-4 text-sm text-muted-foreground">
                  Auditing website, drafting emails, generating subject lines...
                </p>
              </CardContent>
            </Card>
          )}

          {result && (
            <>
              <Card className="border-border bg-gradient-surface shadow-elegant">
                <CardHeader>
                  <CardTitle className="font-display">Website analysis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm leading-relaxed text-foreground/90">
                    {result.analysis.summary}
                  </p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {(
                      [
                        ["Design quality", result.analysis.design_quality],
                        ["Mobile responsiveness", result.analysis.mobile_responsiveness],
                        ["Loading speed", result.analysis.loading_speed],
                        ["Outdated elements", result.analysis.outdated_elements],
                        ["Missing CTAs", result.analysis.missing_ctas],
                        ["SEO", result.analysis.seo],
                        ["User experience", result.analysis.ux],
                        ["Branding", result.analysis.branding],
                      ] as const
                    ).map(([k, v]) => (
                      <div
                        key={k}
                        className="rounded-lg border border-border bg-background/40 p-3"
                      >
                        <div className="text-xs font-semibold text-primary">{k}</div>
                        <div className="mt-1 text-xs text-muted-foreground">{v}</div>
                      </div>
                    ))}
                  </div>
                  {result.analysis.conversion_opportunities?.length > 0 && (
                    <div>
                      <div className="mb-2 text-sm font-semibold">
                        Conversion opportunities
                      </div>
                      <ul className="space-y-1.5">
                        {result.analysis.conversion_opportunities.map((o, i) => (
                          <li key={i} className="flex gap-2 text-sm text-foreground/90">
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            <span>{o}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border bg-gradient-surface shadow-elegant">
                <CardHeader>
                  <CardTitle className="font-display">Outreach emails</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="standard">
                    <TabsList className="grid w-full grid-cols-5">
                      <TabsTrigger value="short">Short</TabsTrigger>
                      <TabsTrigger value="standard">Standard</TabsTrigger>
                      <TabsTrigger value="premium">Premium</TabsTrigger>
                      <TabsTrigger value="followup_1">Follow-up 1</TabsTrigger>
                      <TabsTrigger value="followup_2">Follow-up 2</TabsTrigger>
                    </TabsList>
                    {(
                      ["short", "standard", "premium", "followup_1", "followup_2"] as const
                    ).map((key) => (
                      <TabsContent key={key} value={key} className="mt-4">
                        <div className="relative rounded-lg border border-border bg-background/40 p-4">
                          <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-foreground/90">
                            {result.emails[key]}
                          </pre>
                          <Button
                            size="sm"
                            variant="outline"
                            className="absolute right-3 top-3"
                            onClick={() => copy(result.emails[key])}
                          >
                            <Copy className="mr-1 h-3 w-3" /> Copy
                          </Button>
                        </div>
                      </TabsContent>
                    ))}
                  </Tabs>
                </CardContent>
              </Card>

              <Card className="border-border bg-gradient-surface shadow-elegant">
                <CardHeader>
                  <CardTitle className="font-display">Subject lines</CardTitle>
                </CardHeader>
                <CardContent className="space-y-5">
                  {(
                    [
                      ["Curiosity", result.subject_lines.curiosity],
                      ["Professional", result.subject_lines.professional],
                      ["Direct", result.subject_lines.direct],
                      ["Benefit", result.subject_lines.benefit],
                      ["Personalized", result.subject_lines.personalized],
                    ] as const
                  ).map(([label, items]) => (
                    <div key={label}>
                      <div className="mb-2 flex items-center gap-2">
                        <Badge variant="outline" className="border-primary/30 text-primary">
                          {label}
                        </Badge>
                      </div>
                      <div className="space-y-1.5">
                        {items?.map((s, i) => (
                          <button
                            key={i}
                            onClick={() => copy(s)}
                            className="group flex w-full items-center justify-between rounded-md border border-border bg-background/40 px-3 py-2 text-left text-sm transition hover:border-primary/40"
                          >
                            <span>{s}</span>
                            <Copy className="h-3 w-3 opacity-0 transition group-hover:opacity-100" />
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {leadId && (
                <div className="text-xs text-muted-foreground">
                  Saved to your library — view in{" "}
                  <button
                    className="underline"
                    onClick={() => navigate({ to: "/saved" })}
                  >
                    Saved Emails
                  </button>
                  .
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
