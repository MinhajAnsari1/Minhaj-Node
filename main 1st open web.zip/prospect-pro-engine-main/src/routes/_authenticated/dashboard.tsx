import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, TrendingUp, Bookmark, Sparkles, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

type Lead = {
  id: string;
  business_name: string;
  industry: string | null;
  created_at: string;
};

function getStoredLeads(): Lead[] {
  try {
    return JSON.parse(localStorage.getItem("leadforge-leads") || "[]");
  } catch {
    return [];
  }
}

function DashboardPage() {
  const leads = getStoredLeads().slice(0, 5);
  const total = getStoredLeads().length;

  const stats = [
    { label: "Total leads", value: total, icon: Bookmark },
    { label: "Emails generated", value: total * 5, icon: Mail },
    { label: "Avg. conversion lift", value: "+34%", icon: TrendingUp },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-8 p-6 md:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Your outreach engine at a glance.
          </p>
        </div>
        <Link to="/generate">
          <Button className="bg-gradient-primary shadow-glow">
            <Sparkles className="mr-2 h-4 w-4" />
            New lead
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label} className="border-border bg-gradient-surface shadow-elegant">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {s.label}
              </CardTitle>
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary">
                <s.icon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="font-display text-3xl font-bold">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border bg-gradient-surface shadow-elegant">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="font-display">Recent leads</CardTitle>
            <p className="text-xs text-muted-foreground">Your latest generated prospects</p>
          </div>
          <Link to="/saved">
            <Button variant="ghost" size="sm">
              View all <ArrowRight className="ml-1 h-3 w-3" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {leads.length === 0 ? (
            <div className="rounded-lg border border-dashed border-border p-10 text-center">
              <Sparkles className="mx-auto h-8 w-8 text-primary" />
              <h3 className="mt-3 font-display text-lg font-semibold">No leads yet</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Generate your first outreach email in under a minute.
              </p>
              <Link to="/generate">
                <Button className="mt-4 bg-gradient-primary shadow-glow">Get started</Button>
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {leads.map((l) => (
                <li key={l.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="font-medium">{l.business_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {l.industry ?? "—"} · {new Date(l.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <Link to="/saved">
                    <Button variant="ghost" size="sm">
                      Open
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
