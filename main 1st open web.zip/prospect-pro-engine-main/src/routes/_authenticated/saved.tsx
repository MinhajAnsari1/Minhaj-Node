import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Copy, Download, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export const Route = createFileRoute("/_authenticated/saved")({
  component: SavedPage,
});

type Lead = {
  id: string;
  business_name: string;
  website_url: string | null;
  industry: string | null;
  contact_name: string | null;
  location: string | null;
  tone: string | null;
  created_at: string;
  emails: Record<string, string> | null;
  subject_lines: Record<string, string[]> | null;
};

function getStoredLeads(): Lead[] {
  try {
    return JSON.parse(localStorage.getItem("leadforge-leads") || "[]");
  } catch {
    return [];
  }
}

function setStoredLeads(leads: Lead[]) {
  localStorage.setItem("leadforge-leads", JSON.stringify(leads));
}

function SavedPage() {
  const [q, setQ] = useState("");
  const [leads, setLeads] = useState<Lead[]>(getStoredLeads);

  const filtered = leads.filter(
    (l) =>
      !q ||
      l.business_name.toLowerCase().includes(q.toLowerCase()) ||
      (l.industry ?? "").toLowerCase().includes(q.toLowerCase()),
  );

  const copy = (t: string) => {
    navigator.clipboard.writeText(t);
    toast.success("Copied");
  };

  const remove = (id: string) => {
    const updated = leads.filter((l) => l.id !== id);
    setStoredLeads(updated);
    setLeads(updated);
    toast.success("Deleted");
  };

  const exportCsv = () => {
    if (filtered.length === 0) return;
    const rows = filtered.map((l) => ({
      business: l.business_name,
      website: l.website_url ?? "",
      industry: l.industry ?? "",
      contact: l.contact_name ?? "",
      location: l.location ?? "",
      tone: l.tone ?? "",
      created: new Date(l.created_at).toISOString(),
      short_email: l.emails?.short ?? "",
      standard_email: l.emails?.standard ?? "",
      premium_email: l.emails?.premium ?? "",
      followup_1: l.emails?.followup_1 ?? "",
      followup_2: l.emails?.followup_2 ?? "",
    }));
    const headers = Object.keys(rows[0]);
    const escape = (v: string) => `"${v.replace(/"/g, '""')}"`;
    const csv = [
      headers.join(","),
      ...rows.map((r) =>
        headers.map((h) => escape(String(r[h as keyof typeof r] ?? ""))).join(","),
      ),
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `leadforge-leads-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exported CSV");
  };

  return (
    <div className="mx-auto max-w-6xl space-y-6 p-6 md:p-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Saved Emails</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every lead you've generated, organized by business.
          </p>
        </div>
        <Button variant="outline" onClick={exportCsv} disabled={filtered.length === 0}>
          <Download className="mr-2 h-4 w-4" /> Export CSV
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by business or industry..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="pl-9"
        />
      </div>

      {filtered.length === 0 ? (
        <Card className="border-dashed border-border bg-card/30">
          <CardContent className="py-16 text-center text-sm text-muted-foreground">
            No saved leads yet.
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border bg-gradient-surface shadow-elegant">
          <CardContent className="p-0">
            <Accordion type="single" collapsible>
              {filtered.map((l) => (
                <AccordionItem key={l.id} value={l.id} className="border-border px-4">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex flex-1 items-center justify-between pr-4">
                      <div className="text-left">
                        <div className="font-semibold">{l.business_name}</div>
                        <div className="text-xs text-muted-foreground">
                          {l.industry ?? "—"} ·{" "}
                          {new Date(l.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pb-4">
                      {l.emails && (
                        <Tabs defaultValue="standard">
                          <TabsList className="grid w-full grid-cols-5">
                            <TabsTrigger value="short">Short</TabsTrigger>
                            <TabsTrigger value="standard">Standard</TabsTrigger>
                            <TabsTrigger value="premium">Premium</TabsTrigger>
                            <TabsTrigger value="followup_1">F/U 1</TabsTrigger>
                            <TabsTrigger value="followup_2">F/U 2</TabsTrigger>
                          </TabsList>
                          {(
                            [
                              "short",
                              "standard",
                              "premium",
                              "followup_1",
                              "followup_2",
                            ] as const
                          ).map((k) => (
                            <TabsContent key={k} value={k} className="mt-3">
                              <div className="relative rounded-lg border border-border bg-background/40 p-4">
                                <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                                  {l.emails?.[k] ?? ""}
                                </pre>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="absolute right-3 top-3"
                                  onClick={() => copy(l.emails?.[k] ?? "")}
                                >
                                  <Copy className="mr-1 h-3 w-3" /> Copy
                                </Button>
                              </div>
                            </TabsContent>
                          ))}
                        </Tabs>
                      )}
                      <div className="flex justify-end">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => remove(l.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="mr-1 h-3 w-3" /> Delete
                        </Button>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
