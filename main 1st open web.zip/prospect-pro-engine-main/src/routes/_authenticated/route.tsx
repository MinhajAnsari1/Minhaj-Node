import { createFileRoute, Outlet, ClientOnly } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  return (
    <ClientOnly fallback={<div className="min-h-screen bg-background" />}>
      <AppShell>
        <Outlet />
      </AppShell>
    </ClientOnly>
  );
}
