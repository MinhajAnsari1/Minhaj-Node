import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/settings")({
  component: SettingsPage,
});

function getStoredAgency() {
  try {
    return JSON.parse(localStorage.getItem("leadforge-agency") || "{}");
  } catch {
    return {};
  }
}

function setStoredAgency(data: Record<string, string>) {
  localStorage.setItem("leadforge-agency", JSON.stringify(data));
}

function SettingsPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [form, setForm] = useState({
    agency_name: "",
    agency_website: "",
    agency_contact: "",
    services: "",
    portfolio: "",
    usp: "",
    target_industry: "",
    default_tone: "Professional",
    email_length: "Standard",
    personalization_level: "High",
    cta_style: "Soft",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const data = getStoredAgency();
    if (data && Object.keys(data).length > 0) {
      setForm({
        agency_name: data.agency_name ?? "",
        agency_website: data.agency_website ?? "",
        agency_contact: data.agency_contact ?? "",
        services: data.services ?? "",
        portfolio: data.portfolio ?? "",
        usp: data.usp ?? "",
        target_industry: data.target_industry ?? "",
        default_tone: data.default_tone ?? "Professional",
        email_length: data.email_length ?? "Standard",
        personalization_level: data.personalization_level ?? "High",
        cta_style: data.cta_style ?? "Soft",
      });
    }
    setIsLoading(false);
  }, []);

  const save = async () => {
    setSaving(true);
    setStoredAgency(form);
    setSaving(false);
    toast.success("Settings saved");
  };

  const upd = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  if (isLoading)
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-6 md:p-8">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your agency profile powers personalization in every generated email.
        </p>
      </div>

      <Card className="border-border bg-gradient-surface shadow-elegant">
        <CardHeader>
          <CardTitle className="font-display">Agency profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Agency name</Label>
              <Input
                value={form.agency_name}
                onChange={(e) => upd("agency_name", e.target.value)}
                placeholder="Pixel Forge Studio"
              />
            </div>
            <div className="space-y-2">
              <Label>Agency website</Label>
              <Input
                value={form.agency_website}
                onChange={(e) => upd("agency_website", e.target.value)}
                placeholder="pixelforge.com"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Contact info</Label>
            <Input
              value={form.agency_contact}
              onChange={(e) => upd("agency_contact", e.target.value)}
              placeholder="alex@pixelforge.com · +1 555 1234"
            />
          </div>
          <div className="space-y-2">
            <Label>Services offered</Label>
            <Textarea
              value={form.services}
              onChange={(e) => upd("services", e.target.value)}
              placeholder="Website redesigns, e-commerce, SEO, conversion optimization..."
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label>Portfolio examples</Label>
            <Textarea
              value={form.portfolio}
              onChange={(e) => upd("portfolio", e.target.value)}
              placeholder="Notable past clients or case studies..."
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label>Unique selling proposition</Label>
            <Textarea
              value={form.usp}
              onChange={(e) => upd("usp", e.target.value)}
              placeholder="What makes your agency different?"
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label>Target industry focus</Label>
            <Input
              value={form.target_industry}
              onChange={(e) => upd("target_industry", e.target.value)}
              placeholder="e.g. local service businesses, e-commerce, SaaS"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-border bg-gradient-surface shadow-elegant">
        <CardHeader>
          <CardTitle className="font-display">AI defaults</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Default tone</Label>
            <Select
              value={form.default_tone}
              onValueChange={(v) => upd("default_tone", v)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["Professional", "Friendly", "Premium", "Direct"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Email length</Label>
            <Select value={form.email_length} onValueChange={(v) => upd("email_length", v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["Short", "Standard", "Long"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Personalization level</Label>
            <Select
              value={form.personalization_level}
              onValueChange={(v) => upd("personalization_level", v)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["Low", "Medium", "High"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>CTA style</Label>
            <Select value={form.cta_style} onValueChange={(v) => upd("cta_style", v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["Soft", "Direct", "Question", "Calendar Link"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={save}
          disabled={saving}
          className="bg-gradient-primary shadow-glow"
        >
          {saving ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          Save settings
        </Button>
      </div>
    </div>
  );
}
