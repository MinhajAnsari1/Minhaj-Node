import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Zap, Target, Mail, BarChart3, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Minhaj Node — Cold Email Generator for Web Design Agencies" },
      {
        name: "description",
        content:
          "Analyze prospect websites and generate personalized outreach emails that book meetings. Built for web design agencies.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0 bg-glow" />
      <div className="pointer-events-none absolute -left-40 top-40 h-[500px] w-[500px] rounded-full bg-primary/20 blur-[140px]" />
      <div className="pointer-events-none absolute -right-40 top-96 h-[500px] w-[500px] rounded-full bg-primary-glow/10 blur-[140px]" />

      {/* Nav */}
      <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-primary shadow-glow">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-display text-lg font-bold tracking-tight">Minhaj Node</span>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/generate">
            <Button size="sm" className="bg-gradient-primary shadow-glow">
              Start generating
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative z-10 mx-auto max-w-5xl px-6 pt-20 pb-24 text-center">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-primary-glow" />
          AI-powered outreach for web design agencies
        </div>
        <h1 className="font-display text-5xl font-bold leading-[1.05] tracking-tight md:text-7xl">
          Cold emails that
          <br />
          <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            actually convert.
          </span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          Drop in a prospect's website. Minhaj Node audits design, UX, and conversion gaps —
          then writes personalized outreach emails ready to send.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <Link to="/generate">
            <Button size="lg" className="bg-gradient-primary px-8 shadow-glow">
              Start generating leads
            </Button>
          </Link>
          <a href="#features">
            <Button size="lg" variant="outline">
              See how it works
            </Button>
          </a>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative z-10 mx-auto max-w-6xl px-6 pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              icon: BarChart3,
              title: "Website audit in seconds",
              body: "Instant analysis of design, mobile UX, SEO, and conversion gaps for any URL.",
            },
            {
              icon: Mail,
              title: "5 email variations",
              body: "Short, standard, premium, plus two follow-ups. Personalized to every prospect.",
            },
            {
              icon: Target,
              title: "10 subject lines",
              body: "Curiosity, professional, benefit, personalized — pick what fits the prospect.",
            },
            {
              icon: Zap,
              title: "Templates by niche",
              body: "Restaurants, dentists, law firms, real estate, e-commerce and more.",
            },
            {
              icon: ShieldCheck,
              title: "Sounds human",
              body: "No spammy claims. No exaggeration. Just specific, trust-building copy.",
            },
            {
              icon: Sparkles,
              title: "Save & export",
              body: "Manage every lead in one dashboard. Copy or export to CSV in one click.",
            },
          ].map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="group rounded-2xl border border-border bg-gradient-surface p-6 shadow-elegant transition hover:border-primary/40"
            >
              <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary/20">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="relative z-10 border-t border-border py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Minhaj Node. Built for agencies that ship.
      </footer>
    </div>
  );
}
